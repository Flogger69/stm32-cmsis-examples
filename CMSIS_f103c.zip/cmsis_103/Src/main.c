

#include <stdint.h>
#include "main.h"

static void delay (unsigned int time) {
    for (unsigned int i = 0; i < time; i++)
        for (volatile unsigned int j = 0; j < 2000; j++);
}

int main(void)
{

RCC->APB2ENR |= RCC_APB2ENR_IOPCEN;
GPIOC->CRH &= ~(GPIO_CRH_CNF13);
GPIOC->CRH |= GPIO_CRH_MODE13_1;


    /* Loop forever */
	while(1){
        GPIOC->BSRR = GPIO_BSRR_BR13;

        delay(500);

        // Set the state of pin 13 to output high
        GPIOC->BSRR = GPIO_BSRR_BS13;

        delay(500);
	}
	return(0);
}
